package edu.persistencia.DAO;

import java.sql.SQLException;
import java.util.List;

import edu.persistencia.DBConnection;

public class DocumentoDAO extends DBConnection implements DAO {

	@Override
	public void insertar(Object objeto) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modificar(Object objeto) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eliminar(Object objeto) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Object> consultar() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> consultarByName(Object objeto) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
